@extends('layouts.frontend')
@section('slider')

@endsection
