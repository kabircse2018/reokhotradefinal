@extends('layouts.frontend')

@section('title', "$about->about_meta_name")
@section('meta_description', "$about->about_meta_description")
@section('meta_meta_keyword', "$about->about_meta_keyword")
@section('author', "HUMAUN KABIR")

@section('content')
		<!-- Banner -->
<div class="banner banner-static has-bg bg-secondary">
    <div class="banner-cpn">
        <div class="container">
            <div class="content row">

                <div class="banner-text">
                    <h1 class="page-title">about us</h1>
                </div>
                <div class="page-breadcrumb">
                    <ul class="breadcrumb">
                        <li><a href="{{url('/')}}">Home</a></li>
                        <li class="active"><a href="{{url('/about')}}"><span>about us</span></a></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <div class="banner-bg imagebg">
        <img src="image/banner-inner.jpg" alt="" />
    </div>
</div>
<!-- End Banner -->



<!-- Content -->
<div class="section section-content section-pad">
<div class="container">
    <div class="content row">

        <div class="row row-vm">
            {{-- <div class="col-sm-6">

                <img src="{{ asset($about->about_image) }}" width="800" height="450" alt="">
            </div> --}}
            <div class="contact-details col-md-12    col-md-offset-1">
                @if(session()->get('lang') == 'japan')
                <h3 class="text-center"><strong>{{$about->about_name_jpn}}</strong></h3>
                {!! $about->about_description_jpn !!}
                @else
                <h3 class="text-center"><strong>{{$about->about_name}}</strong></h3>
                {!! $about->about_description !!}
                @endif
              


                {{-- <ul class="contact-list">
                    <li><i class="fa fa-graduation-cap" aria-hidden="true"></i>
                        <span>Student Admission Services</span>
                    </li>
                    <li><i class="fa fa-handshake-o" aria-hidden="true"></i>
                        <span>Services for UK University</span>
                    </li>

                </ul> --}}
            </div>

        </div>



    </div>
</div>
</div>
<!-- End Content -->
@endsection


